
backend/
├── controllers/
├── routes/
├── services/
├── middlewares/
├── prisma/
├── validations/
└── modules/

frontend/
├── components/
├── pages/
├── layouts/
├── services/
├── hooks/
├── contexts/
├── routes/
└── styles/
